/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionClientes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author 1daw
 */
public class ConexionBD {

    public static void main(String[] args) {
        try {
            String url = "jdbc:mysql://localhost:3306/jardineria";
            Connection connection = DriverManager.getConnection(url, "root", "123456");
            Statement stmt=connection.createStatement();
            System.out.println("Conectado con la base de datos de forma exitosa");
        } catch (SQLException e) {
            System.out.println("No se ha podido establecer conexión con la base de datos");
        }
    }

}
