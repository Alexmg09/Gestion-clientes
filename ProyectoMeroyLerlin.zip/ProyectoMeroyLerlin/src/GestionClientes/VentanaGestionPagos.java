
package GestionClientes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentanaGestionPagos extends javax.swing.JFrame {


    public VentanaGestionPagos() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelGestionPagos = new javax.swing.JLabel();
        jButtonRealizarPago = new javax.swing.JButton();
        jButtonEliminarPago = new javax.swing.JButton();
        jButtonActualizarPago = new javax.swing.JButton();
        jButtonBuscarPago = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePagos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 255, 51));

        jLabelGestionPagos.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabelGestionPagos.setForeground(new java.awt.Color(255, 255, 255));
        jLabelGestionPagos.setText("Gesti�n de pagos");

        jButtonRealizarPago.setText("Realizar pago");
        jButtonRealizarPago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRealizarPagoActionPerformed(evt);
            }
        });

        jButtonEliminarPago.setText("Eliminar pago");
        jButtonEliminarPago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarPagoActionPerformed(evt);
            }
        });

        jButtonActualizarPago.setText("Actualizar pago");
        jButtonActualizarPago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarPagoActionPerformed(evt);
            }
        });

        jButtonBuscarPago.setText("Buscar pago");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("MEROY LERL�N");

        jTablePagos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id_pago", "forma de pago", "id_transaccion", "fecha_pago", "total"
            }
        ));
        jScrollPane1.setViewportView(jTablePagos);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(372, 372, 372)
                        .addComponent(jLabelGestionPagos))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonRealizarPago)
                            .addComponent(jButtonBuscarPago))
                        .addGap(35, 35, 35)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(jButtonActualizarPago))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addComponent(jButtonEliminarPago))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addComponent(jLabel1)))
                .addContainerGap(88, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jLabel1)
                .addGap(70, 70, 70)
                .addComponent(jLabelGestionPagos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 74, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonRealizarPago)
                        .addGap(170, 170, 170)
                        .addComponent(jButtonBuscarPago))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jButtonActualizarPago)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButtonEliminarPago))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(69, 69, 69))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonRealizarPagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRealizarPagoActionPerformed
          Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "123456");
            if (conn != null) {
                System.out.println("Se ha podido establecer conexi�n con la base de datos");
                String id_cliente = JOptionPane.showInputDialog(rootPane, "id_cliente", "Realizar pago", JOptionPane.HEIGHT);
                String formaPago = JOptionPane.showInputDialog(rootPane, "Forma de pago", "Realizar pago", JOptionPane.HEIGHT);
                String fechaPago = JOptionPane.showInputDialog(rootPane, "Fecha pago", "Realizar pago", JOptionPane.HEIGHT);
                String totalPago = JOptionPane.showInputDialog(rootPane, "Pago total", "Realizar pago", JOptionPane.HEIGHT);
               
                
                
               // Pago pago = new Pago();
                //List<Pago> pagos = new ArrayList<>();

                DefaultTableModel tm = new DefaultTableModel();
                jTablePagos.setModel(tm);
            } else {
                System.out.println("No se ha podido establecer conexi�n con la base de datos");
            }
        } catch (SQLException ex) {
            Logger.getLogger(VentanaGestionPagos.class.getName()).log(Level.SEVERE, "Error al conectar con la base de datos", ex);
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    Logger.getLogger(VentanaGestionPagos.class.getName()).log(Level.SEVERE, "Error al cerrar la conexi�n con la base de datos", ex);
                }
            }
        }
    }//GEN-LAST:event_jButtonRealizarPagoActionPerformed

    private void jButtonEliminarPagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarPagoActionPerformed
        String eliminarPago = JOptionPane.showInputDialog(rootPane, "Eliminar", "Eliminar pago", JOptionPane.HEIGHT);
        
    }//GEN-LAST:event_jButtonEliminarPagoActionPerformed

    private void jButtonActualizarPagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonActualizarPagoActionPerformed
         String actualizarMetodoPago = JOptionPane.showInputDialog(rootPane, "Actualizar metodo de pago", "Actualizar pago", JOptionPane.HEIGHT);
         String nuevoMetodoPago = JOptionPane.showInputDialog(rootPane, "Introduzca nuevo metodo de pago", "Actualizar pago", JOptionPane.HEIGHT);
    }//GEN-LAST:event_jButtonActualizarPagoActionPerformed

 public static void main(String[] args) {

    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new VentanaGestionPagos().setVisible(true);
        }
    });
}
 


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonActualizarPago;
    private javax.swing.JButton jButtonBuscarPago;
    private javax.swing.JButton jButtonEliminarPago;
    private javax.swing.JButton jButtonRealizarPago;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelGestionPagos;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePagos;
    // End of variables declaration//GEN-END:variables
}
