
package GestionClientes;

import java.math.BigDecimal;
import java.util.Date;

public class Pago {
    private Cliente cliente;
    private int codigoCliente;
    private String formaPago;
    private String idTransaccion;
    private Date fechaPago;
    private BigDecimal total;

   
    public Pago() {
    }


    public Pago(int codigoCliente, String formaPago, String idTransaccion, Date fechaPago, BigDecimal total, Cliente cliente) {
        this.cliente=cliente;
        this.codigoCliente = codigoCliente;
        this.formaPago = formaPago;
        this.idTransaccion = idTransaccion;
        this.fechaPago = fechaPago;
        this.total = total;
    }


    public int getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(int codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public String getIdTransaccion() {
        return idTransaccion;
    }

    public void setIdTransaccion(String idTransaccion) {
        this.idTransaccion = idTransaccion;
    }

    public Date getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(Date fechaPago) {
        this.fechaPago = fechaPago;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }
}
